@extends('layouts.admin')

@section('content')

<div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Departments</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a>Home</a>
                        </li>
                        <li class="active">
                            <a>departments</a>
                        </li>
                        

                    </ol>
                </div>
            </div>

@endsection